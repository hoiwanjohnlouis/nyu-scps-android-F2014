package com.thehackerati.academy;

/**
 * Created by rob on 9/13/14.
 */
public interface IContact {
}
