package com.thehackerati.academy;

public class Main {

    public static void main(String[] args) {
	// write your code here
        IContact me = new Person("Smith", "John");
        System.out.println(me);
    }
}
